export default {
  items: [
    {
      id: "navigation",
      title: "Navigation",
      type: "group",
      icon: "icon-navigation",
      children: [
        {
          id: "dashboard",
          title: "Dashboard",
          type: "item",
          url: "/dashboard/default",
          icon: "feather icon-home"
        }
      ]
    },
    {
      id: "ui-element",
      title: "Shift Report",
      type: "group",
      icon: "icon-ui",
      children: [
        {
          id: "Areaa",
          title: "Area 1",
          type: "collapse",
          icon: "feather icon-file",
          children: [
            {
              id: "a1psrlist",
              title: "Production Supervisor Report",
              type: "item",
              url: "/productionsupervisorlist/a1"
            },
            {
              id: "a1asr",
              title: "Area Supervisor Report",
              type: "item",
              url: "/areasupervisorlist/a1"
            },
            {
              id: "a1report",
              title: "Area A Report",
              type: "item",
              url: "/areaa"
            },
            {
              id: "a1cr",
              title: "Console Report",
              type: "item",
              url: "/consolereport"
            },
            {
              id: "a1fr",
              title: "Field Report",
              type: "item",
              url: "/field"
            }
            /*{
              id: "breadcrumb-pagination",
              title: "Process Operator",
              type: "item",
              url: "/shiftreport"
            }*/
          ]
        },
        {
          id: "Area2",
          title: "Area 2",
          type: "collapse",
          icon: "feather icon-file",
          children: [
            {
              id: "productionsupervisorreport",
              title: "Production Supervisor Report",
              type: "item",
              url: "/productionsupervisor"
            },
            {
              id: "areasupervisorreport",
              title: "Area Supervisor Report",
              type: "item",
              url: "/areasupervisor"
            },
            {
              id: "areaareport",
              title: "Area A Report",
              type: "item",
              url: "/areaa"
            },
            {
              id: "consolereport",
              title: "Console Report",
              type: "item",
              url: "/consolereport"
            },
            {
              id: "fieldreport",
              title: "Field Report",
              type: "item",
              url: "/field"
            }
            /*{
              id: "breadcrumb-pagination",
              title: "Process Operator",
              type: "item",
              url: "/shiftreport"
            }*/
          ]
        },
        {
          id: "Area3",
          title: "Area 3",
          type: "collapse",
          icon: "feather icon-file",
          children: [
            {
              id: "productionsupervisorreport",
              title: "Production Supervisor Report",
              type: "item",
              url: "/productionsupervisor"
            },
            {
              id: "areasupervisorreport",
              title: "Area Supervisor Report",
              type: "item",
              url: "/areasupervisor"
            },
            {
              id: "areaareport",
              title: "Area A Report",
              type: "item",
              url: "/areaa"
            },
            {
              id: "consolereport",
              title: "Console Report",
              type: "item",
              url: "/consolereport"
            },
            {
              id: "fieldreport",
              title: "Field Report",
              type: "item",
              url: "/field"
            }
            /*{
              id: "breadcrumb-pagination",
              title: "Process Operator",
              type: "item",
              url: "/shiftreport"
            }*/
          ]
        },
        {
          id: "Area4",
          title: "Area 4",
          type: "collapse",
          icon: "feather icon-file",
          children: [
            {
              id: "productionsupervisorreport",
              title: "Production Supervisor Report",
              type: "item",
              url: "/productionsupervisor"
            },
            {
              id: "areasupervisorreport",
              title: "Area Supervisor Report",
              type: "item",
              url: "/areasupervisor"
            },
            {
              id: "area4report",
              title: "Area 4 Report",
              type: "item",
              url: "/areaa"
            },
            {
              id: "consolereport",
              title: "Console Report",
              type: "item",
              url: "/consolereport"
            },
            {
              id: "fieldreport",
              title: "Field Report",
              type: "item",
              url: "/field"
            }
            /*{
              id: "breadcrumb-pagination",
              title: "Process Operator",
              type: "item",
              url: "/shiftreport"
            }*/
          ]
        },
        {
          id: "Area5",
          title: "Area 5",
          type: "collapse",
          icon: "feather icon-file",
          children: [
            {
              id: "a5psr",
              title: "Production Supervisor Report",
              type: "item",
              url: "/productionsupervisor"
            },
            {
              id: "a5asr",
              title: "Area Supervisor Report",
              type: "item",
              url: "/areasupervisor"
            },
            {
              id: "a5report",
              title: "Area 4 Report",
              type: "item",
              url: "/areaa"
            },
            {
              id: "a5cr",
              title: "Console Report",
              type: "item",
              url: "/consolereport"
            },
            {
              id: "a5freport",
              title: "Field Report",
              type: "item",
              url: "/field"
            }
            /*{
              id: "breadcrumb-pagination",
              title: "Process Operator",
              type: "item",
              url: "/shiftreport"
            }*/
          ]
        }
      ]
    },
    {
      id: "ui-element",
      title: "Administration",
      type: "group",
      icon: "icon-ui",
      children: [
        {
          id: "Administration",
          title: "Administration",
          type: "collapse",
          icon: "feather icon-server",
          children: [
            {
              id: "button",
              title: "Production Supervisor",
              type: "item",
              url: "/productionsupervisor"
            },
            {
              id: "badges",
              title: "Area Supervisor",
              type: "item",
              url: "/basic/badges"
            },
            {
              id: "badges",
              title: "Area A",
              type: "item",
              url: "/basic/badges"
            },
            {
              id: "badges",
              title: "Console Report",
              type: "item",
              url: "/basic/badges"
            },
            {
              id: "badges",
              title: "Field Report",
              type: "item",
              url: "/basic/badges"
            },
            {
              id: "breadcrumb-pagination",
              title: "Process Operator",
              type: "item",
              url: "/shiftreport"
            }
          ]
        }
      ]
    }
  ]
};
