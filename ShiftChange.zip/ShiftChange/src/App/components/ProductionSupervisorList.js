import React from "react";
import {
  Row,
  Col,
  Card,
  Tooltip,
  OverlayTrigger,
  Table,
  Button
} from "react-bootstrap";
import Aux from "../../hoc/_Aux";
import API from "../../api";

class ProductionSupervisorList extends React.Component {
  constructor(props) {
    super(props);
    this.state = { reportlist: [] };
  }

  // * Handle button click
  handleChange = event => {
    console.log("click eevent");
    this.props.history.push("/productionsupervisor/");
  };

  //* Get data from API. GET
  componentDidMount() {
    //* Get the parameter from URL
    const { area } = this.props.match.params;
    console.log(area);
    API.get("shiftreport/1").then(res => {
      const report = res.data;
      this.setState({ reportlist: report });
      console.log(report);
    });
  }

  render() {
    return (
      <Aux>
        <Row>
          <Col md={6} xl={4}>
            <Card>
              <Card.Body>
                <h4 className="mb-4">Area Supervisor Instructions:</h4>
                <div className="row d-flex align-items-center">
                  <div className="col-9">
                    <h4 className="f-w-300 d-flex align-items-center m-b-0">
                      Instruction here.
                    </h4>
                  </div>

                  <div className="col-3 text-right">
                    <p className="m-b-0"></p>
                  </div>
                </div>
                <div className="progress m-t-30" style={{ height: "7px" }}>
                  <div
                    className="progress-bar progress-c-theme"
                    role="progressbar"
                    style={{ width: "100%" }}
                    aria-valuenow="50"
                    aria-valuemin="0"
                    aria-valuemax="100"
                  />
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>
        <Row>
          <Col>
            <Card>
              <Card.Header>
                <Card.Title as="h5">Reports</Card.Title>
              </Card.Header>
              <Card.Body>
                <Row>
                  <Col md={12}>
                    <Table responsive hover>
                      <thead>
                        <tr>
                          <th>Report Name</th>
                          <th>Created Date</th>
                          <th>Created By</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>
                            <OverlayTrigger
                              overlay={
                                <Tooltip>
                                  Area 1 Production Supervisor Report- Day Shift
                                  Report
                                </Tooltip>
                              }
                            >
                              <Button
                                variant="link"
                                onClick={this.handleChange}
                              >
                                Area1-PSR-20191224-DAY
                              </Button>
                            </OverlayTrigger>
                          </td>
                          <td>12/24/2019</td>
                          <td>Colten Shackelford</td>
                        </tr>
                        <tr>
                          <td>
                            <OverlayTrigger
                              overlay={
                                <Tooltip>
                                  Area 1 Production Supervisor Report- Night
                                  Shift Report
                                </Tooltip>
                              }
                            >
                              <Button variant="link">
                                Area1-PSR-20191224-NIGHT
                              </Button>
                            </OverlayTrigger>
                          </td>
                          <td>12/24/2019</td>
                          <td>Chris White</td>
                        </tr>
                        <tr>
                          <td>
                            <OverlayTrigger
                              overlay={
                                <Tooltip>
                                  Area 1 Production Supervisor Report- Day Shift
                                  Report
                                </Tooltip>
                              }
                            >
                              <Button variant="link">
                                Area1-PSR-20191223-NIGHT
                              </Button>
                            </OverlayTrigger>
                          </td>
                          <td>12/23/2019</td>
                          <td>LANCE BROWN</td>
                        </tr>
                      </tbody>
                    </Table>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Aux>
    );
  }
}
export default ProductionSupervisorList;
